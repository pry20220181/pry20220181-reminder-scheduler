class ReminderScheduler:
    def __init__(self):
        pass

if __name__ == '__main__':
    print('This is the ReminderScheduler module for PRY20220181 Reminder Scheduler Lambda')